#include<stdlib.h>
#include<iostream>
#include<fstream>
#include <string>
#define RGB_COMPONENT_COLOR 255
#include"omp.h"

struct PPMPixel
{
  int red;
  int green;
  int blue;

};

typedef struct
{
  int x, y, all;
  PPMPixel *data;

} PPMImage;

  int n, m; 
  PPMPixel **A;
  
void
readPPM (const char *filename, PPMImage & img)
{
  std::ifstream file (filename);
  if (file)
    {
      std::string s;
      int rgb_comp_color;
      file >> s;
      if (s != "P3")
	{
	  std::cout << "error in format" << std::endl;
	  exit (9);
	}
      file >> img.x >> img.y;
      file >> rgb_comp_color;
      img.all = img.x * img.y;
      std::cout << s << std::endl;
      std::cout << "x=" << img.x <<"y=" << img.y << "all=" << img.all;
      img.data = new PPMPixel[img.all];
      for (int i = 0; i < img.all; i++)
	{
	  file >> img.data[i].red >> img.data[i].green >> img.data[i].blue;
	}


    }
  else
    {
      std::cout << "the file:" << filename << "was not found" << std::endl;
    }
  file.close ();
}

void
writePPM (const char *filename)
{
  std::ofstream file (filename, std::ofstream::out);
  file << "P3" << std::endl;
  file << m << " " << n << " " << std::endl;
  file << RGB_COMPONENT_COLOR << std::endl;
  
  int i=0, j=0;
  for (int k = 0; k < n*m; k++)
    {
      file << A[i][j].red << " " << A[i][j].green << " " << A[i][j].blue << (((k + 1) % m == 0) ? "\n" : " ");
	        j=j+1;
        if ((k + 1) % m == 0) {
            i++; j=0;}
    }
  file.close ();
}

int
main ()
{
  PPMImage image;
  readPPM ("car.ppm", image);
  n=image.y;
  m=image.x; 
  
   A = (PPMPixel**) calloc(n*(m+1),sizeof(PPMPixel*));
   for(int i=0; i<n; i++)
            A[i] = (PPMPixel*) calloc(m+1,sizeof(PPMPixel));
            
    // copy image.data in to a matrix A
    int i=0, j=0;
    for (int k = 0; k < image.all; k++)
    {
        A[i][j]=image.data[k];
        j=j+1;
        if ((k + 1) % m == 0) {
            i++; j=0;}
    }
    
      omp_set_num_threads(4);    
      for (int k=0; k<m; k++)
      {  
          // here we distribute rows of A among threads j-->j+1 j=0,1,...,m-1
          #pragma omp parallel for shared(A) private(i) 
          for(int i=0; i<n; i++)
            {
            // here we can't use omp, because A depends its previous value          
           for(int j=m-1; j>=0; j--) A[i][j+1]=A[i][j]; 
          }
          
          // here we distribute rows of A among threads (copy column m --> 0 column)
          #pragma omp parallel for shared(A) private(i) 
          for(int i=0; i<n; i++) A[i][0]=A[i][m];

          std::string fname = "image_out" + std::to_string(k)+".ppm";
          writePPM (fname.c_str());
      }

    for (int i = 0; i < n; i++) free(A[i]);
    free(A);

  return 0;
}



