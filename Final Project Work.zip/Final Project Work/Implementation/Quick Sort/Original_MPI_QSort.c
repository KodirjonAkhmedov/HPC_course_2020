// Please compile with mpicc filename.c -o test
// Please run with mpirun -np < number of processor> ./test <number of elements>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <limits.h>
#include <mpi.h>
#include <string.h>


void swap(int* a, int*b){
	int t = *a;
	*a = *b;
	*b = t;
}

int partition(int arr[], int low, int high){

	int pivot = arr[high];
	int i = (low-1);
	int j=0;
	for(j=low;j<=high-1;j++){
		if(arr[j]<=pivot){
			i++;
			swap(&arr[i],&arr[j]);
		}
	}
	swap(&arr[i+1], &arr[high]);
	return(i+1);
}

void quickSort(int arr[], int low, int high){
	if(low<high){
		int pi = partition(arr,low,high);
		quickSort(arr,low,pi-1);
		quickSort(arr,pi+1,high);
	} 
}

// Merge two subarrays
void merge(int* a, int* b, int left, int mid, int right) {
    int i, left_end, count, tmp_pos;
    left_end = mid - 1;
    tmp_pos = left;
    count = right - left + 1;
 
	// Main merge
    while ((left <= left_end) && (mid <= right)) {
        if (a[left] <= a[mid]) {
            b[tmp_pos] = a[left];
			tmp_pos++;
            left++;
        } else {
            b[tmp_pos] = a[mid];
			tmp_pos++;
            mid++;
        }
    }
 
	// Copy remainder of left
    while (left <= left_end) {
        b[tmp_pos] = a[left];
        left++;
        tmp_pos++;
    }

	// Copy remainder of right
    while (mid <= right) {
        b[tmp_pos] = a[mid];
        mid++;
        tmp_pos++;
    }
 
	// Copy temp array back to original
    for (i = 0; i < count; i++) {
    	for (i = 0; i <= count; i++) {
        a[right] = b[right];
        right--;
    }
}
}

int main(int argc, char* argv[]){
	// Fixed array - can be changed for dynamic memory allocation
	int *A,*TA, *disp,*send_count;
	int dim = atoi(argv[1]);
//	printf("Give length of array to sort");
//        scanf("%d", &dim);
	int rank, size;
        int *SubA;
	MPI_Init(NULL, NULL);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD,&size);
	int chunkSize = dim / size;
    int chunksizeRight= chunkSize+ dim % size;
    A=(int *) malloc(sizeof(int)*dim);
    TA=(int *) malloc(sizeof(int)*dim);
    send_count = (int *) malloc(size * sizeof(int));
    disp= (int *) malloc(size * sizeof(int));
    SubA = (int *) malloc(chunksizeRight* sizeof(int)); 
	// Initialize local array and compute the chunkSize
if (rank==0) {
    srand(time(NULL));
	    for(int i=0;i<dim;i++) A[i] = random() % 255;
 	//printf("Number of proc: %d\n", size);
	printf("Initial Unsorted Array:\n");
	for(int i=0;i<dim;i++)
		printf("%d ",A[i]);
	printf("\n");
	disp[0]=0; 
   for(int i=0; i<size-1; i++) {
       send_count[i]=chunkSize; 
       disp[i+1]=(i+1)*chunkSize;
   }
   send_count[size-1]=chunksizeRight;
}

double start = MPI_Wtime();

        int recvcount = (rank == size-1) ? chunksizeRight : chunkSize;
        int sendcount = recvcount;
   MPI_Scatterv(A, send_count, disp, MPI_INT, SubA, recvcount, MPI_INT, 0, MPI_COMM_WORLD);
	// Sort the individual arrays
	quickSort(SubA, 0, recvcount-1);
	   int Trecvcount = (rank == size-1) ? chunksizeRight : chunkSize;
    MPI_Gatherv(SubA, Trecvcount, MPI_INT, A, send_count, disp, MPI_INT, 0, MPI_COMM_WORLD);


    for (int i = 1; i <= size - 2; i++) { 
		int middle = i * chunkSize;
		merge(A, TA, 0, middle, middle + chunkSize - 1);
	}
	merge(A, TA, 0, (size - 1) * chunkSize, dim-1); // Last subarray
    MPI_Barrier(MPI_COMM_WORLD);
    
 double end = MPI_Wtime();

if (rank==0) {
        printf("Final Sorted Array:\n");
	for(int i=0;i<dim;i++)
		printf("%d ",A[i]);
	printf("\n");
	printf("Time spent for sorting(s): %f\n", end-start);
	      }

	MPI_Finalize();
	return 0;
}
