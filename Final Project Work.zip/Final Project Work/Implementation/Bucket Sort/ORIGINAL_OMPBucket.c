// Please use with gcc -fopenmp filename -o test
// Please compile with ./test press enter
// After you will be asked to enter number of elements and thread number 

#include <omp.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#define max_threads 80

struct bucket {
    int n_elem;
    int index; 
};

int cmpfunc (const void * a, const void * b)
{
 return ( *(int*)a - *(int*)b );
}

int main(int argc, char *argv[]) {

    int *A, *B, *Telm;
    int dim, n_buckets, i, w, limit, num_threads;
    struct bucket* buckets; //array of buckets
    double t1; // Timing variable
    float total; //total time

    printf("Give length of array to sort \n");
    if (scanf("%d", &dim) != 1){
        printf("error\n");
        return -1;
    }
    printf("Give number of threads \n");
    if (scanf("%d", &n_buckets) != 1){
        printf("error\n");
        return -1;
    }
  
 
    num_threads = n_buckets;
   omp_set_num_threads(num_threads);

    limit = 10000000;
    w = limit/n_buckets;
    A = (int *) malloc(sizeof(int)*dim);
    B= (int *) malloc(sizeof(int)*dim);
    Telm= (int *) malloc(sizeof(int)*n_buckets);
//    tmp = (int *) malloc(sizeof(int)*dim);
    
    for(i=0;i<dim;i++) {
	    A[i] = random() % limit;
	}
	
	if (dim <= limit) {
        printf("Initial Unsorted Array \n");
        for(i=0;i<dim;i++) {
            printf("%d ",A[i]);
        }
        printf("\n");
    }
 buckets = (struct bucket *) calloc(n_buckets, sizeof(struct bucket));

// Starting the main algorithm
// ****************************

    t1 = omp_get_wtime();
#pragma omp parallel
{
    num_threads = omp_get_num_threads();

    int j,k;
    int local_index;
    int my_id = omp_get_thread_num();

   #pragma omp for private(i,local_index)
    for (i=0; i< dim;i++){
        local_index = A[i]/w;
        if (local_index > n_buckets-1) local_index = n_buckets-1;
        buckets[local_index].n_elem++;
	}   
	#pragma omp barrier

#pragma omp master
  {
    for (i=0; i< n_buckets;i++) {
	Telm[i]=buckets[i].n_elem; 
    if (i!=n_buckets-1) buckets[i+1].index=buckets[i].index+buckets[i].n_elem; 
	}
  }
	#pragma omp barrier

   #pragma omp for private(i, local_index)
    for (i=0; i< dim;i++){
        local_index = A[i]/w; if (local_index > n_buckets-1) local_index = n_buckets-1;
        int idx = buckets[local_index].index + Telm[local_index]-1;
        Telm[local_index]--;
        B[idx] = A[i];
	}	
	#pragma omp barrier

   #pragma omp for private(i)
    for(i=0; i<n_buckets; i++)
        qsort(B+buckets[i].index, buckets[i].n_elem, sizeof(int), cmpfunc);
}
    total = omp_get_wtime() - t1;
//	A = B;

    printf("Final Sorted Array \n");
    for(i=0;i< dim;i++) printf("%d ", B[i]);
    printf("\n");
    printf("Time spent for sorting(s) %f\n", total);

 return 0;
}
