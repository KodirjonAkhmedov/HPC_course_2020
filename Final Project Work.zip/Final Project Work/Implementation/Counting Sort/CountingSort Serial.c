//Please compile with gcc filename.c -o test
// Please run with ./test <number of elements>


#include <stdio.h> 
#include <stdlib.h>  
#include <time.h> 
#define RANGE 255   
int N; 
// The main function that sort   
// the given string arr[] in   
// alphabatical order   
void countSort(int *arr)   
{   
    // The output character array   
    // that will have sorted arr   
    int *output = (int*)malloc(N * sizeof(int));    
   
    // Create a count array to store count of inidividul   
    // characters and initialize count array as 0   
    int *count, i;   
    count=(int*)calloc(RANGE+1, sizeof(int));   
   
    // Store count of each character   
    for(i = 0; i<N; ++i)   
        ++count[arr[i]];   
   
    // Change count[i] so that count[i] now contains actual   
    // position of this character in output array   
    for (i = 1; i <= RANGE; ++i)   
        count[i] += count[i-1];   
   
    // Build the output character array   
    for (i = 0; i<N; ++i)   
    {   
        output[count[arr[i]]-1] = arr[i];   
        --count[arr[i]];   
    }   
   
    for (i = 0; i<N; ++i)   
        arr[i] = output[i];   
}   
   
// Driver  code  
int main(int argc, char *argv[])   
{ 
        //clock_t CPU_time_1 = clock();  
 clock_t t; 
 t = clock(); 
 //time_t begin,end; 
 //begin= time(NULL); 
        N = atoi(argv[1]); 
    srand(time(NULL)); 
    int* a = (int*)malloc(N * sizeof(int));  
    printf("Initial Array\n"); 
    for (int i = 0; i < N; i++) { 
        a[i] = rand()%256;printf("%d ",a[i]);} 
    printf("\n"); 
    countSort(a);   
        printf("Sorted Array\n"); 
        for(int i = 0; i < N; i++) printf("%d ",a[i]); 
 printf("\n"); 
 t = clock() - t; 
        double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds 
 printf("Counting Sequential took %f seconds to sort the integer array. \n", time_taken); 
 //end = time(NULL); 
 //clock_t CPU_time_2 = clock(); 
 //printf("for loop used %f seconds to complete the execution\n", difftime(end, begin)); 
 
 
return 0;   
}
