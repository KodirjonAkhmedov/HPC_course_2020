// Please compile with mpicc filename.c -o test
// Please run with mpirun -np <number of processors> ./test <number of elements>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <limits.h>
#include <mpi.h>
#define RANGE 256 // we are giving the maximum randon number here 

int main(int argc, char* argv[]){

	// Fixed array - can be changed for dynamic memory allocation
	int *A,*output, *disp,*send_count;
	int dim = atoi(argv[1]);
	int rank, size;
    int *SubA;
	MPI_Init(NULL, NULL);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD,&size);
	int chunkSize = dim / size;
    int chunksizeRight= chunkSize+ dim % size;
    A=(int *) malloc(sizeof(int)*dim);
    output=(int *) malloc(sizeof(int)*dim);
    send_count = (int *) malloc(size * sizeof(int));
    disp= (int *) malloc(size * sizeof(int));
    SubA = (int *) malloc(chunksizeRight* sizeof(int)); 
    int *count;   
    count=(int*)calloc(RANGE, sizeof(int)); 
	// Initialize local array and compute the chunkSize
if (rank==0) {
    srand(time(NULL));
	    for(int i=0;i<dim;i++) A[i] = random() % RANGE;
 	//printf("Number of proc: %d\n", size);
	printf("Initial unsorted array:\n");
	for(int i=0;i<dim;i++)
		printf("%d ",A[i]);
	printf("\n");
	disp[0]=0; 
   for(int i=0; i<size-1; i++) {
       send_count[i]=chunkSize; 
       disp[i+1]=(i+1)*chunkSize;
   }
   send_count[size-1]=chunksizeRight;
}

double start = MPI_Wtime();

        int recvcount = (rank == size-1) ? chunksizeRight : chunkSize;
        int sendcount = recvcount;
   MPI_Scatterv(A, send_count, disp, MPI_INT, SubA, recvcount, MPI_INT, 0, MPI_COMM_WORLD);

        // Count 
   
   for(int i = 0; i<recvcount; ++i)  ++count[SubA[i]];
   MPI_Barrier(MPI_COMM_WORLD); 
   for (int i = 1; i <= RANGE; ++i)  count[i] += count[i-1];

   recvcount = (rank == size-1) ? chunksizeRight : chunkSize;
         sendcount = recvcount;
   MPI_Scatterv(A, send_count, disp, MPI_INT, SubA, recvcount, MPI_INT, 0, MPI_COMM_WORLD);
	// output 
	    for (int i = 0; i<recvcount; ++i)   
    {   
        output[count[SubA[i]]-1] = SubA[i];   
        --count[SubA[i]];   
    } 
    
	int Trecvcount = (rank == size-1) ? chunksizeRight : chunkSize;
    MPI_Gatherv(output, Trecvcount, MPI_INT, A, send_count, disp, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);
    
 double end = MPI_Wtime();

if (rank==0) {
        printf("Final sorted array:\n");
	for(int i=0;i<dim;i++)
		printf("%d ",A[i]);
	printf("\n");
	printf("Time spent for running(s): %f\n", end-start);
	      }

	MPI_Finalize();
	return 0;
}


















