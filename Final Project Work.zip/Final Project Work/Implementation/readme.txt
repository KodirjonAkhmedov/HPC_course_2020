- Bubble Sort and Counting Sort were compared with its serial versions

- Merge Sort, Quick Sort, Comb Sort, Bucket Sort were compared with different processors namely with 1 processor and 2 processors respectively.
